# Webhook Regata — Jotform → Slack

Notifie automatiquement #sales- à chaque contrat signé.

## Déploiement sur Render (gratuit)

### 1. Mettre le code sur GitHub
Crée un dépôt privé GitHub et push ces deux fichiers :
- `index.js`
- `package.json`

### 2. Créer le service sur Render
1. Va sur https://render.com → New → Web Service
2. Connecte ton repo GitHub
3. Paramètres :
   - **Name** : webhook-regata
   - **Runtime** : Node
   - **Build command** : *(laisser vide)*
   - **Start command** : `node index.js`
4. Dans **Environment Variables**, ajoute :
   - `SLACK_TOKEN` = ton token Slack Bot (xoxb-...)

### 3. Récupérer ton token Slack Bot
1. Va sur https://api.slack.com/apps → crée une app (ou utilise une existante)
2. OAuth & Permissions → ajoute le scope `chat:write`
3. Installe l'app dans ton workspace
4. Copie le **Bot User OAuth Token** (xoxb-...)
5. Invite le bot dans #sales- : `/invite @nom-du-bot`

### 4. Configurer le webhook dans Jotform
Pour chacun des deux formulaires :
1. Ouvre le formulaire → Settings → Integrations → WebHooks
2. Webhook URL : `https://webhook-regata.onrender.com/webhook`
3. Save

C'est tout — chaque nouvelle signature déclenche automatiquement la notification.

## Ajouter un nouvel agent commercial
Dans `index.js`, ligne EMAIL_TO_PRENOM, ajoute :
```js
"nouvelagent@domaine.fr": "Prénom",
```
